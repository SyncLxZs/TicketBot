module.exports = async(client) => {
    console.log('Bot Inicializado');
}